﻿namespace PROJECT_GLUTTON
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.파일수납갯수설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.보안ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.안전한수납ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.안전한이동ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.드래그시비밀번호입력ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.설정ToolStripMenuItem,
            this.보안ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(717, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 설정ToolStripMenuItem
            // 
            this.설정ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.파일수납갯수설정ToolStripMenuItem});
            this.설정ToolStripMenuItem.Name = "설정ToolStripMenuItem";
            this.설정ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.설정ToolStripMenuItem.Text = "설정";
            this.설정ToolStripMenuItem.Click += new System.EventHandler(this.설정ToolStripMenuItem_Click);
            // 
            // 파일수납갯수설정ToolStripMenuItem
            // 
            this.파일수납갯수설정ToolStripMenuItem.Name = "파일수납갯수설정ToolStripMenuItem";
            this.파일수납갯수설정ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.파일수납갯수설정ToolStripMenuItem.Text = "파일 수납 갯수 설정";
            this.파일수납갯수설정ToolStripMenuItem.Click += new System.EventHandler(this.파일수납갯수설정ToolStripMenuItem_Click);
            // 
            // 보안ToolStripMenuItem
            // 
            this.보안ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.안전한수납ToolStripMenuItem,
            this.안전한이동ToolStripMenuItem,
            this.드래그시비밀번호입력ToolStripMenuItem});
            this.보안ToolStripMenuItem.Name = "보안ToolStripMenuItem";
            this.보안ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.보안ToolStripMenuItem.Text = "보안";
            this.보안ToolStripMenuItem.Click += new System.EventHandler(this.보안ToolStripMenuItem_Click);
            // 
            // 안전한수납ToolStripMenuItem
            // 
            this.안전한수납ToolStripMenuItem.CheckOnClick = true;
            this.안전한수납ToolStripMenuItem.Enabled = false;
            this.안전한수납ToolStripMenuItem.Name = "안전한수납ToolStripMenuItem";
            this.안전한수납ToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.안전한수납ToolStripMenuItem.Text = "안전한 수납";
            this.안전한수납ToolStripMenuItem.Click += new System.EventHandler(this.안전한수납ToolStripMenuItem_Click);
            // 
            // 안전한이동ToolStripMenuItem
            // 
            this.안전한이동ToolStripMenuItem.CheckOnClick = true;
            this.안전한이동ToolStripMenuItem.Name = "안전한이동ToolStripMenuItem";
            this.안전한이동ToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.안전한이동ToolStripMenuItem.Text = "드래그 시 이동";
            this.안전한이동ToolStripMenuItem.Click += new System.EventHandler(this.안전한이동ToolStripMenuItem_Click);
            // 
            // 드래그시비밀번호입력ToolStripMenuItem
            // 
            this.드래그시비밀번호입력ToolStripMenuItem.CheckOnClick = true;
            this.드래그시비밀번호입력ToolStripMenuItem.Name = "드래그시비밀번호입력ToolStripMenuItem";
            this.드래그시비밀번호입력ToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.드래그시비밀번호입력ToolStripMenuItem.Text = "드래그 시 비밀번호 입력";
            this.드래그시비밀번호입력ToolStripMenuItem.Click += new System.EventHandler(this.드래그시비밀번호입력ToolStripMenuItem_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(460, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "수납 현황 : ";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(535, 3);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(64, 21);
            this.textBox3.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(604, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(11, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "/";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(622, 3);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(67, 21);
            this.textBox4.TabIndex = 8;
            // 
            // listView1
            // 
            this.listView1.AllowDrop = true;
            this.listView1.LargeImageList = this.imageList1;
            this.listView1.Location = new System.Drawing.Point(12, 30);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(693, 494);
            this.listView1.TabIndex = 9;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listView1.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView1_DragDrop);
            this.listView1.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView1_DragEnter);
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "문서.jpg");
            this.imageList1.Images.SetKeyName(1, "사진.jpg");
            this.imageList1.Images.SetKeyName(2, "영상.jpg");
            this.imageList1.Images.SetKeyName(3, "파일.jpg");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 536);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Glutton";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 파일수납갯수설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 보안ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 안전한수납ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 안전한이동ToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ToolStripMenuItem 드래그시비밀번호입력ToolStripMenuItem;
        private System.Windows.Forms.ImageList imageList1;
    }
}

