﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PROJECT_GLUTTON
{
    public partial class Form1 : Form
    {
        PeFileHeaderReader PE;
        bool erasecheck;   // absolute erase?
        bool change_fact; //  check the file change
        bool absolute_erase;
        int max_file_number;
        int now_file_number;
        bool enc; // 암호화?
        int slot_num;
        int init;
        int[] count;
        uint pad_loc;
        String result;
        String key;
        String numberOfStorage;
        String[,] name_crypt;
        SEED sd = new SEED();
        //암호화 sd.seedEncryptString("키", "평문");
        //복호화 sd.seedDecryptString("키", "암호문"); 인풋 스트링 아웃풋 스트링
        public Form1()
        {
            erasecheck = false;
            change_fact = false;
            absolute_erase = false;
            InitializeComponent();
            max_file_number = 0;
            now_file_number = 0;
            slot_num = 20;
            init = 0;
            enc = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int temp = 0;
            String sourcepath = System.Windows.Forms.Application.ExecutablePath; // 현재 실행 경로
            String[] destpath = sourcepath.Split('.');
            result = destpath[0] + "copyed.exe";
            try // file copy
            { 
                File.Copy(sourcepath, result);
            }
            catch
            {
               //MessageBox.Show("실행 오류!");
            }

            PE = new PeFileHeaderReader(result); // 현 exe pe 포맷 갖고오기
            using (var stream = new FileStream(result, System.IO.FileMode.Open, System.IO.FileAccess.ReadWrite))
            {
                var reader = new BinaryReader(stream);
                var writer = new BinaryWriter(stream);

                pad_loc = PE.SectionHeader.PointerToRawData + PE.SectionHeader.SizeOfRawData; // 패딩 위치

                reader.BaseStream.Position = stream.Seek(pad_loc, SeekOrigin.Begin) - 2;
                max_file_number = (int)reader.ReadByte();

                if (max_file_number == 0)
                {
                    name_crypt = new String[20, 2];
                    count = new int[20];
                    max_file_number = 20;
                    stream.Position = stream.Seek(pad_loc, SeekOrigin.Begin) - 2;
                    stream.WriteByte((Byte)slot_num);
                    stream.WriteByte(0);

                    for (int i = 0; i < slot_num; i++) //슬럿 초기화
                        writer.Write(init);
                }
                else
                {
                    name_crypt = new String[max_file_number, 2];
                    count = new int[max_file_number];
                    reader.BaseStream.Position = stream.Seek(pad_loc, SeekOrigin.Begin);

                    for (now_file_number = 0; now_file_number < max_file_number; now_file_number++)
                    {
                        temp = reader.ReadInt32();
                        if (temp == 0)
                            break;
                        count[now_file_number] = temp;
                    }
                   
                    reader.BaseStream.Position = stream.Seek(pad_loc + (4 * max_file_number), SeekOrigin.Begin) ;
                    for (int i = 0; i < now_file_number; i++)
                    {
                        temp = reader.ReadInt32();
                        String stemp = new String(reader.ReadChars(temp));
                        name_crypt[i, 0] = stemp;
                        if (reader.ReadBytes(32).Equals(0x0))
                        {
                            name_crypt[i, 1] = "0";
                        }
                        else
                        {
                            name_crypt[i, 1] = "1";
                        }
                        reader.BaseStream.Position = stream.Seek(count[i], SeekOrigin.Current);
                    }
                    
                }

            }

            textBox4.Text = max_file_number.ToString();
            textBox3.Text = now_file_number.ToString();

            for (int i = 0; i <now_file_number; i++) // 저장 불러오기
            {
                String[] tem = name_crypt[i, 0].Split('.'); 
                AddListView(name_crypt[i, 0], tem[1]);
            }
           
        }

        private void file_input(String path, String ifile, bool enc, String key)
        {
            char[] filename = new char[255];
            byte[] hash_code = new byte[16];
            int size = 0;
            int temp = 0;
            String ctemp;

            change_fact = true;
            filename = ifile.Substring(ifile.LastIndexOf("\\") + 1).ToCharArray(); // 넣는 파일 이름 
            //pad_loc = PE.SectionHeader.PointerToRawData + PE.SectionHeader.SizeOfRawData; // 패딩 위치

            using (var stream = new FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.ReadWrite))
            {
                FileInfo info = new FileInfo(ifile);
                FileStream instream = new FileStream(ifile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                //info랑 instream 이랑 중복 사용되어있음, 수정 요함
                var writer = new BinaryWriter(stream);
                var reader = new BinaryReader(stream);

                if (now_file_number == 0) // 처음 실행
                {
                    ctemp = new String(filename); // 넣고 바로뺄때를 대비한 배열값 추가
                    name_crypt[0, 0]=ctemp;
                    writer.BaseStream.Position = stream.Seek(pad_loc, SeekOrigin.Begin);
                    writer.Write((int)(info.Length + (info.Length % 16))); // 파일 사이즈
                    count[0] = (int)(info.Length + (info.Length % 16));
                    writer.BaseStream.Position = stream.Seek(pad_loc, SeekOrigin.Begin) + (4 * max_file_number);
                    writer.Write(filename.Count()); //파일 이름 사이즈
                    writer.Write(filename); // 이름
                    

                    if (enc == true) // 암호화시
                    {
                        name_crypt[0, 1] = "1";
                        hash_code= Convert.FromBase64String(sd.seedEncryptString(key, key));
                        writer.Write(hash_code);
                        size = (int)instream.Length;
                        byte[] buff = new byte[size];
                        instream.Read(buff, 0, size);
                        byte[] enbuff= new byte[size+ info.Length % 16];
                        enbuff = Convert.FromBase64String(sd.seedEncryptString(key, Convert.ToBase64String(buff)));
                        writer.Write(enbuff);
                        count[0] = enbuff.Length;
                    }
                    else // 비암호화
                    {
                        name_crypt[0, 1] = "0";
                        writer.Write(hash_code);

                        // 파일 삽입 시작
                        size = (int)instream.Length;
                        byte[] buff = new byte[size];
                        instream.Read(buff, 0, size);
                        writer.Write(buff);
                        // 파일 삽입 끝

                        // 패딩 삽입
                        for (int i = 0; i < info.Length % 16; i++)
                            writer.Write((byte)0);
                        // 패딩 삽입 끝

                    }

                }
                else // 2번째 실행
                {
                    ctemp = new String(filename); // 넣고 바로뺄때를 대비한 배열값 추가
                    name_crypt[now_file_number, 0] = ctemp;
                    writer.BaseStream.Position = stream.Seek(pad_loc, SeekOrigin.Begin) + (4 * now_file_number); // 파일 사이즈 기재
                    writer.Write((int)(info.Length + (info.Length % 16))); // 파일 사이즈
                    count[now_file_number] = (int)(info.Length + (info.Length % 16));
                    reader.BaseStream.Position = stream.Seek(pad_loc, SeekOrigin.Begin) + (4 * max_file_number);
                    for (int i = 0; i < now_file_number; i++)
                    {
                        temp = reader.ReadInt32();
                        reader.BaseStream.Position = stream.Seek(temp + 16 + count[i], SeekOrigin.Current);
                    }
                    writer.BaseStream.Position = reader.BaseStream.Position;
                    writer.Write(filename.Count()); //파일 이름 사이즈
                    writer.Write(filename); // 이름

                    if (enc == true) // 암호화시
                    {
                        name_crypt[now_file_number,1]="1";
                        hash_code = Convert.FromBase64String(sd.seedEncryptString(key, key));
                        writer.Write(hash_code);
                        size = (int)instream.Length;
                        byte[] buff = new byte[size];
                        instream.Read(buff, 0, size);
                        byte[] enbuff = new byte[size + info.Length % 16];
                        enbuff = Convert.FromBase64String(sd.seedEncryptString(key, Convert.ToBase64String(buff)));
                        writer.Write(enbuff);
                        count[now_file_number] = enbuff.Length;
                    }
                    else // 비암호화
                    {
                        name_crypt[now_file_number, 1] = "0";
                        writer.Write(hash_code);

                        // 파일 삽입 시작
                        size = (int)instream.Length;
                        byte[] buff = new byte[size];
                        int n = instream.Read(buff, 0, size);
                        writer.Write(buff);
                        // 파일 삽입 끝

                        // 패딩 삽입
                        for (int i = 0; i < info.Length % 16; i++)
                            writer.Write((byte)0);
                        // 패딩 삽입 끝

                    }

                }
                if (erasecheck == true) // 완전한 삭제 부분은 추후 수정
                {
                    if (absolute_erase==true)
                    {
                        instream.Dispose();  // fileinfo가 dispose되야 함!
                        WIPING(ifile);
                    }
                    else
                    {
                        instream.Dispose();
                        info.Delete();
                    }
                }
            }
            textBox3.Text = (++now_file_number).ToString();
        }
        private void file_output(String path,String filename,String key,bool enc, ref bool wrong)  // 파일 빼내기
        {
            int name_length = 0;
            int init_buffer = 0;

            change_fact = true;
            using (var stream = new FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.ReadWrite))
            {
                byte[] hash_check = new byte[16];
                bool equal_check = true;
                byte[] temp;
                int temp_len;
                int current_file;
                int end_position;
                int current_position;
                int pull_size;
                BinaryWriter writer = new BinaryWriter(stream);
                BinaryReader reader = new BinaryReader(stream);
               
                for (int i = 0; i < now_file_number; i++)
                {
                    if (name_crypt[i, 0].Equals(filename))
                    {
                        // 슬럿 삭제
                        textBox3.Text=(now_file_number-1).ToString();
                        if (i==max_file_number-1 || i == now_file_number - 1) // 제일 끝 슬럿일때
                        {
                            writer.BaseStream.Position = stream.Seek(pad_loc + (4 * i), SeekOrigin.Begin);
                            writer.Write(init_buffer);
                        }
                        else // 처음 혹은 중간 슬럿일때
                        {
                            temp_len = (max_file_number * 4) - ((4 * i) + 4);
                            temp = new byte[temp_len];
                            reader.BaseStream.Position = stream.Seek(pad_loc + (4 * i) + 4, SeekOrigin.Begin);
                            temp = reader.ReadBytes(temp_len);
                            writer.BaseStream.Position = stream.Seek(pad_loc + (4 * i), SeekOrigin.Begin);
                            writer.Write(temp);
                            writer.Write(init_buffer);
                        }

                        reader.BaseStream.Position = stream.Seek(pad_loc + (4 * max_file_number), SeekOrigin.Begin);
                        for (int j = 0; j < i; j++)
                        {
                            name_length = reader.ReadInt32(); // 이름 길이
                            reader.BaseStream.Position = stream.Seek(name_length +16+count[i],SeekOrigin.Current); // 이름길이 + 해쉬값 32바이트 + 실제 사이즈 만큼 넘어감
                        }
                        current_file = (int)reader.BaseStream.Position;
                        name_length = reader.ReadInt32();
                        reader.BaseStream.Position = stream.Seek(name_length, SeekOrigin.Current); // 이름과 길이 뛰어넘음
                        hash_check=reader.ReadBytes(16);
                        // 원하는 위치 도착

                        for (int k = 0; k < 16; k++) // 암호화 되었는지 체크
                        {
                            if (hash_check[k] != 0)
                            {
                                equal_check = false;
                                break;
                            }
                        }

                        if (equal_check==false)
                        {
                            if (!Convert.ToBase64String(hash_check).Equals(sd.seedDecryptString(key, Convert.ToBase64String(hash_check))))
                            {
                                wrong = true;
                                return;
                            }
                            // 복호화 루틴
                            FileInfo file = new FileInfo(Application.StartupPath + "\\" + name_crypt[i, 0]);
                            FileStream fs = file.Create();

                            byte[] buffer = new byte[count[i]];
                            buffer = reader.ReadBytes(count[i]);
                            String cry_temp = Convert.ToBase64String(buffer);
                            String temp_b = sd.seedDecryptString(key,cry_temp);
                            fs.Write(Convert.FromBase64String(temp_b),0, Convert.FromBase64String(temp_b).Length);
                            fs.Close();
                        }
                        else
                        {
                            // 비 암호화시
                            FileInfo file = new FileInfo(Application.StartupPath+"\\"+name_crypt[i, 0]);
                            FileStream fs = file.Create();

                            byte[] buffer = new byte[count[i]];
                            buffer = reader.ReadBytes(count[i]);
                            fs.Write(buffer,0,count[i]);
                            fs.Close();
                        }
                        //이름길이+이름+해쉬+실제값 삭제 및 당기기]
                        end_position = (int)stream.Length;
                        current_position = (int)reader.BaseStream.Position;
                        pull_size = end_position - current_position;
                        if (pull_size != 0) // 끝 부분이 아니라면
                        {
                            byte[] pull_buffer = new byte[pull_size];
                            pull_buffer = reader.ReadBytes(pull_size);
                            writer.BaseStream.Position = current_file;
                            writer.Write(pull_buffer);
                        }
                        stream.SetLength(end_position-(name_length+20+count[i]));

                        if (i != now_file_number-1)
                        {
                            for (int k = i+1; k < now_file_number + 1; k++)
                            {
                                count[k - 1] = count[k];
                                name_crypt[k - 1, 0] = name_crypt[k,0];
                                name_crypt[k - 1, 1] = name_crypt[k, 1];
                            }
                            count[now_file_number-1] = 0;
                            name_crypt[now_file_number-1, 0] = null;
                            name_crypt[now_file_number-1, 1] = null;
                        }
                        else
                        {
                            count[now_file_number-1] = 0;
                            name_crypt[now_file_number-1, 0] = null;
                            name_crypt[now_file_number-1, 1] = null;
                        }

                        now_file_number--;
                        break;
                    }
                }
               
            }
        }

        private void WIPING(String path)
        {
            Random r = new Random();
            using (var stream = new FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.ReadWrite))
            {
                FileInfo info = new FileInfo(path);
                var writer = new BinaryWriter(stream);
                int temp = new int();

                for (int i = 0; i < info.Length/4; i++)
                {
                    r.Next(temp);
                    writer.Write(temp);
                }

                info.Delete();
            }
        }


        private void make_bat(int type)
        {
            String ori_path = System.Windows.Forms.Application.ExecutablePath;
            String bat_path = Application.StartupPath + "\\trans.bat";
            String bat_dat="";
            String ori_name = ori_path.Substring(0,ori_path.Count()-4);
            String pure_name = System.Diagnostics.Process.GetCurrentProcess().ProcessName + ".exe";

            if (type == 1) // 파일 변경없을때
            {
                bat_dat = ":Repeat  \ndel " + ori_name + "copyed.exe" +"\nif exist " + ori_name + "copyed.exe goto Repeat \n" + "del "+bat_path;
            }
            else // 파일 변경
            {
                bat_dat = ":Repeat  \ndel " + ori_path + "\nif exist " + ori_path + " goto Repeat\nren " + ori_name + "copyed.exe " + pure_name+"\ndel " + bat_path;
            }
            
            try
            {
                System.IO.File.WriteAllText(bat_path, bat_dat);
                System.Diagnostics.Process.Start(bat_path);
                // 배치 파일 실행
            }
            catch
            {
            }

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            
            if (change_fact == true)
            {
                make_bat(0);
            }
            else
            {
                make_bat(1);
            }
            
        } // x 버튼 누르면 실행되는 파트

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listView1.DoDragDrop(listView1.SelectedItems, DragDropEffects.Move);
        }

        private void 보안ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 설정ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 파일수납갯수설정ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 파일 수납 갯수 설정창 출력하기
            using (MaxNumberOfStorage mnsForm = new MaxNumberOfStorage())
            {
                mnsForm.ShowDialog();
                numberOfStorage = mnsForm.num;
                change_fact = true;
                change_max_number(result,Int32.Parse(numberOfStorage));
                    
                // numberOfStorage을 int형으로 변환 후 사용 -> Int32.Parse(numberOfStorage);
            }
        }

        private void change_max_number(String path, int max_num)
        {
            using (var stream = new FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.ReadWrite))
            {
                BinaryWriter writer = new BinaryWriter(stream);
                writer.BaseStream.Position = stream.Seek(pad_loc, SeekOrigin.Current)-2;
                writer.Write((Byte)(max_num));
                stream.SetLength(pad_loc);
                slot_num = max_num;
                writer.BaseStream.Position = stream.Seek(pad_loc, SeekOrigin.Current);
                for (int i = 0; i < slot_num; i++) //슬럿 초기화
                    writer.Write(init);
                MessageBox.Show("프로그램을 다시 실행시키십시오");
                make_bat(0);
                Application.Exit();
            }
        }
        private void 안전한이동ToolStripMenuItem_Click(object sender, EventArgs e) // 드래그시 이동
        {
            if (erasecheck == true)
            {
                erasecheck = false;
                안전한수납ToolStripMenuItem.Enabled = false;
                absolute_erase = false;
                안전한수납ToolStripMenuItem.Checked = false;
            }
            else
            {
                erasecheck = true;
                안전한수납ToolStripMenuItem.Enabled = true;
            }
        }

        private void 드래그시비밀번호입력ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (enc == true)
                enc = false;
            else
                enc = true;
        }
        // 파일 끌어다 넣기 효과 켜기
        private void listView1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }
        // 파일 끌어다 넣기
        private void listView1_DragDrop(object sender, DragEventArgs e)
        {
            String[] file = (String[])e.Data.GetData(DataFormats.FileDrop);
            //file[0] 절대경로
            if(now_file_number!=max_file_number)
            { 
            if (enc == true)
            {
                // pw입력창 출력하기
                using (PassWord pwForm = new PassWord())
                {
                    pwForm.ShowDialog();
                    // key = 암호화 키 
                    key = pwForm.key;
                    if (key != null && key != "")
                    {
                        foreach (String filePath in file)
                        {
                            String[] fileName = filePath.Split('\\');
                            String[] fileExtension = fileName[fileName.Length - 1].Split('.');
                            AddListView(fileName[fileName.Length - 1], fileExtension[fileExtension.Length - 1]);
                        }
                    }
                }
            }
            else
            {
                foreach (String filePath in file)
                {
                    String[] fileName = filePath.Split('\\');
                    String[] fileExtension = fileName[fileName.Length - 1].Split('.');
                    AddListView(fileName[fileName.Length - 1], fileExtension[fileExtension.Length - 1]);
                }
            }
            file_input(result, file[0], enc, key);
            }
            else
            {
                MessageBox.Show("슬럿이 꽉 찼습니다.");
            }
        }

        private void AddListView(String fileName, String fileExtension)
        {
            switch (fileExtension)
            {
                case "jpg":
                case "gif":
                case "bmp":
                case "png":
                    listView1.Items.Add(fileName, imageList1.Images.IndexOfKey("사진.jpg"));
                    break;
                case "hwp":
                case "dox":
                case "txt":
                    listView1.Items.Add(fileName, imageList1.Images.IndexOfKey("문서.jpg"));
                    break;
                case "avi":
                case "mkv":
                    listView1.Items.Add(fileName, imageList1.Images.IndexOfKey("영상.jpg"));
                    break;
                default:
                    listView1.Items.Add(fileName, imageList1.Images.IndexOfKey("파일.jpg"));
                    break;
            }
        }

        // 파일 삭제
        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            bool wrong=false;
            if (enc == true)
            {
                // pw입력창 출력하기
                using (PassWord pwForm = new PassWord())
                {
                    pwForm.ShowDialog();
                    // key = 암호화 키 
                    key = pwForm.key;
                    // key 가 원래 키값과 같을때 삭제
                    
                        String temp = listView1.SelectedItems[0].Text;
                        file_output(result, temp, key, enc, ref wrong); //카피된 이름 써야됨
                                                                    // 비번 있을때 삭제 - 바로 추가하면됨
                    if(wrong==false) 
                    {
                        listView1.Items.Remove(listView1.SelectedItems[0]);
                    }
                    else
                    {
                        MessageBox.Show("비밀번호가 틀렸습니다.");
                    }
                }

            }
            else if (enc == false)
            {
                try
                {
                    String temp = listView1.SelectedItems[0].Text;
                    listView1.Items.Remove(listView1.SelectedItems[0]);
                    file_output(result,temp, key, enc,ref wrong); //카피된 이름 써야됨
                    // 비번 없을때 삭제 - 바로 추가하면됨
                }
                catch { }
            }
        }

        private void 안전한수납ToolStripMenuItem_Click(object sender, EventArgs e) // 완전한 삭제
        {
            if (absolute_erase == true)
            {
                absolute_erase = false;
            }
            else
            {
                absolute_erase = true;
            } 
        }
    }

    #region PeFileHeaderReader definition

    public class PeFileHeaderReader
    {
        private readonly IMAGE_DOS_HEADER _dosHeader;
        private readonly IMAGE_FILE_HEADER _fileHeader;
        private readonly IMAGE_Optional_Header _opHeader;
        private readonly IMAGE_Section_Header _secHeader;

        public String Path { get; private set; }

        public PeFileHeaderReader(String path)
        {
            Path = path;

            using (var stream = new FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read))
            {
                var reader = new BinaryReader(stream);

                _dosHeader = FromBinaryReader<IMAGE_DOS_HEADER>(reader);
               
                reader.BaseStream.Position = stream.Seek(_dosHeader.e_lfanew, SeekOrigin.Begin) + 4;

                _fileHeader = FromBinaryReader<IMAGE_FILE_HEADER>(reader);

                reader.BaseStream.Position = stream.Seek(_dosHeader.e_lfanew + 20, SeekOrigin.Begin) + 4;

                _opHeader = FromBinaryReader<IMAGE_Optional_Header>(reader);

                reader.BaseStream.Position = stream.Seek(_dosHeader.e_lfanew + 20 + _fileHeader.SizeOfOptionalHeader + ((_fileHeader.NumberOfSections-1) * System.Runtime.InteropServices.Marshal.SizeOf(typeof(IMAGE_Section_Header))), SeekOrigin.Begin) + 4;

                _secHeader = FromBinaryReader<IMAGE_Section_Header>(reader);

                reader.Close();
            }
        }

        public IMAGE_DOS_HEADER DosHeader
        {
            get
            {
                return _dosHeader;
            }
        }

        public IMAGE_FILE_HEADER FileHeader
        {
            get
            {
                return _fileHeader;
            }
        }

        public IMAGE_Optional_Header OptionalHeader
        {
            get
            {
                return _opHeader;
            }
        }
        public IMAGE_Section_Header SectionHeader
        {
            get
            {
                return _secHeader;
            }
        }

        public static T FromBinaryReader<T>(BinaryReader reader) where T : struct
        {
            byte[] bytes = reader.ReadBytes(Marshal.SizeOf(typeof(T)));

            GCHandle handle = GCHandle.Alloc(bytes, GCHandleType.Pinned);
            var theStructure = (T)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(T));
            handle.Free();

            return theStructure;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct IMAGE_DOS_HEADER
        {
            public UInt16 e_magic;       // Magic number
            public UInt16 e_cblp;        // Bytes on last page of file
            public UInt16 e_cp;         // Pages in file
            public UInt16 e_crlc;        // Relocations
            public UInt16 e_cparhdr;      // Size of header in paragraphs
            public UInt16 e_minalloc;      // Minimum extra paragraphs needed
            public UInt16 e_maxalloc;      // Maximum extra paragraphs needed
            public UInt16 e_ss;         // Initial (relative) SS value
            public UInt16 e_sp;         // Initial SP value
            public UInt16 e_csum;        // Checksum
            public UInt16 e_ip;         // Initial IP value
            public UInt16 e_cs;         // Initial (relative) CS value
            public UInt16 e_lfarlc;       // File address of relocation table
            public UInt16 e_ovno;        // Overlay number
            public UInt16 e_res_0;       // Reserved words
            public UInt16 e_res_1;       // Reserved words
            public UInt16 e_res_2;       // Reserved words
            public UInt16 e_res_3;       // Reserved words
            public UInt16 e_oemid;       // OEM identifier (for e_oeminfo)
            public UInt16 e_oeminfo;      // OEM information; e_oemid specific
            public UInt16 e_res2_0;       // Reserved words
            public UInt16 e_res2_1;       // Reserved words
            public UInt16 e_res2_2;       // Reserved words
            public UInt16 e_res2_3;       // Reserved words
            public UInt16 e_res2_4;       // Reserved words
            public UInt16 e_res2_5;       // Reserved words
            public UInt16 e_res2_6;       // Reserved words
            public UInt16 e_res2_7;       // Reserved words
            public UInt16 e_res2_8;       // Reserved words
            public UInt16 e_res2_9;       // Reserved words
            public UInt32 e_lfanew;       // File address of new exe header
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct IMAGE_FILE_HEADER
        {
            public UInt16 Machine;
            public UInt16 NumberOfSections;
            public UInt32 TimeDateStamp;
            public UInt32 PointerToSymbolTable;
            public UInt32 NumberOfSymbols;
            public UInt16 SizeOfOptionalHeader;
            public UInt16 Characteristics;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct IMAGE_Optional_Header
        {
            public UInt16 magic;
            public byte MajorLinkerVersion;
            public byte MinorLinkerVersion;
            public UInt32 SizeofCode;
            public UInt32 SizeOfIntializedData;
            public UInt16 SizeOfUninitializedData;
            public UInt32 AddressOfEntryPoint;
            public UInt32 BaseOfCode;
            public UInt32 BaseOfData;
            public UInt32 ImageBase;
            public UInt32 SectionAlignment;
            public UInt32 FileAlignment;
            public UInt16 MajorOperatingSystemVersion;
            public UInt16 MinorOperatingSystemVersion;
            public UInt16 MajorImageVersion;
            public UInt16 MinorImageVersion;
            public UInt16 MajorSubsystemVersion;
            public UInt16 MinorSubsystemVersion;
            public UInt32 Win32VersionValue;
            public UInt32 SizeOfImage;
            public UInt32 SizeOfHeaders;
            public UInt32 CheckSum;
            public UInt16 Subsystem;
            public UInt16 DllCharacteristics;
            public UInt32 SizeOfStackReserve;
            public UInt32 SizeOfStackCommit;
            public UInt32 SizeOfHeapReserve;
            public UInt32 SizeOfHeapCommit;
            public UInt32 LoaderFlags;
            public UInt32 NumberOfRvaAndSizes; // 배열 빠짐
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct IMAGE_Section_Header
        {
            public byte Name1;
            public byte Name2;
            public byte Name3;
            public byte Name4;
            public byte Name5;
            public byte Name6;
            public byte Name7;
            public byte Name8;
            public UInt32 VirtualSize;
            public UInt32 VirtualAddress;
            public UInt32 SizeOfRawData;
            public UInt32 PointerToRawData;
            public UInt32 PointerToRelocations;
            public UInt32 PointerToLinenumbers;
            public UInt16 NumberOfRelocations;
            public UInt16 NumberOfLinenumbers;
            public UInt32 Characteristics;
        }
    }
}

#endregion
