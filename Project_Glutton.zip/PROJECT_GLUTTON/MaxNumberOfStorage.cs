﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT_GLUTTON
{
    public partial class MaxNumberOfStorage : Form
    {
        public String num { get; set; }

        public MaxNumberOfStorage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            num = this.textBox1.Text;
            this.Close();
        }
    }
}
