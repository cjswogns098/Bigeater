﻿namespace gluttonGUI
{
    partial class frame_Glutton
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Decryption = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.text_Name1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.text_size1 = new System.Windows.Forms.TextBox();
            this.text_Name2 = new System.Windows.Forms.TextBox();
            this.text_size2 = new System.Windows.Forms.TextBox();
            this.text_Name3 = new System.Windows.Forms.TextBox();
            this.text_size3 = new System.Windows.Forms.TextBox();
            this.text_Name4 = new System.Windows.Forms.TextBox();
            this.text_size4 = new System.Windows.Forms.TextBox();
            this.text_size8 = new System.Windows.Forms.TextBox();
            this.text_Name8 = new System.Windows.Forms.TextBox();
            this.text_size7 = new System.Windows.Forms.TextBox();
            this.text_Name7 = new System.Windows.Forms.TextBox();
            this.text_size6 = new System.Windows.Forms.TextBox();
            this.text_Name6 = new System.Windows.Forms.TextBox();
            this.text_size5 = new System.Windows.Forms.TextBox();
            this.text_Name5 = new System.Windows.Forms.TextBox();
            this.text_Log = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.label3 = new System.Windows.Forms.Label();
            this.radio_File1 = new System.Windows.Forms.RadioButton();
            this.radio_File2 = new System.Windows.Forms.RadioButton();
            this.radio_File3 = new System.Windows.Forms.RadioButton();
            this.radio_File4 = new System.Windows.Forms.RadioButton();
            this.radio_File5 = new System.Windows.Forms.RadioButton();
            this.radio_File6 = new System.Windows.Forms.RadioButton();
            this.radio_File7 = new System.Windows.Forms.RadioButton();
            this.radio_File8 = new System.Windows.Forms.RadioButton();
            this.button_Wiping = new System.Windows.Forms.Button();
            this.button_File = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_Decryption
            // 
            this.button_Decryption.Location = new System.Drawing.Point(34, 94);
            this.button_Decryption.Name = "button_Decryption";
            this.button_Decryption.Size = new System.Drawing.Size(75, 23);
            this.button_Decryption.TabIndex = 2;
            this.button_Decryption.Text = "복호화";
            this.button_Decryption.UseVisualStyleBackColor = true;
            this.button_Decryption.Click += new System.EventHandler(this.button_Decryption_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(136, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "Name";
            // 
            // text_Name1
            // 
            this.text_Name1.Location = new System.Drawing.Point(138, 65);
            this.text_Name1.Name = "text_Name1";
            this.text_Name1.Size = new System.Drawing.Size(114, 21);
            this.text_Name1.TabIndex = 5;
            this.text_Name1.TextChanged += new System.EventHandler(this.text_Name1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(256, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "Size";
            // 
            // text_size1
            // 
            this.text_size1.Location = new System.Drawing.Point(258, 65);
            this.text_size1.Name = "text_size1";
            this.text_size1.Size = new System.Drawing.Size(114, 21);
            this.text_size1.TabIndex = 7;
            this.text_size1.TextChanged += new System.EventHandler(this.text_size1_TextChanged);
            // 
            // text_Name2
            // 
            this.text_Name2.Location = new System.Drawing.Point(138, 92);
            this.text_Name2.Name = "text_Name2";
            this.text_Name2.Size = new System.Drawing.Size(114, 21);
            this.text_Name2.TabIndex = 8;
            this.text_Name2.TextChanged += new System.EventHandler(this.text_Name2_TextChanged);
            // 
            // text_size2
            // 
            this.text_size2.Location = new System.Drawing.Point(258, 92);
            this.text_size2.Name = "text_size2";
            this.text_size2.Size = new System.Drawing.Size(114, 21);
            this.text_size2.TabIndex = 9;
            this.text_size2.TextChanged += new System.EventHandler(this.text_size2_TextChanged);
            // 
            // text_Name3
            // 
            this.text_Name3.Location = new System.Drawing.Point(138, 119);
            this.text_Name3.Name = "text_Name3";
            this.text_Name3.Size = new System.Drawing.Size(114, 21);
            this.text_Name3.TabIndex = 10;
            this.text_Name3.TextChanged += new System.EventHandler(this.text_Name3_TextChanged);
            // 
            // text_size3
            // 
            this.text_size3.Location = new System.Drawing.Point(258, 119);
            this.text_size3.Name = "text_size3";
            this.text_size3.Size = new System.Drawing.Size(114, 21);
            this.text_size3.TabIndex = 11;
            this.text_size3.TextChanged += new System.EventHandler(this.text_size3_TextChanged);
            // 
            // text_Name4
            // 
            this.text_Name4.Location = new System.Drawing.Point(138, 146);
            this.text_Name4.Name = "text_Name4";
            this.text_Name4.Size = new System.Drawing.Size(114, 21);
            this.text_Name4.TabIndex = 12;
            this.text_Name4.TextChanged += new System.EventHandler(this.text_Name4_TextChanged);
            // 
            // text_size4
            // 
            this.text_size4.Location = new System.Drawing.Point(258, 146);
            this.text_size4.Name = "text_size4";
            this.text_size4.Size = new System.Drawing.Size(114, 21);
            this.text_size4.TabIndex = 13;
            this.text_size4.TextChanged += new System.EventHandler(this.text_size4_TextChanged);
            // 
            // text_size8
            // 
            this.text_size8.Location = new System.Drawing.Point(258, 255);
            this.text_size8.Name = "text_size8";
            this.text_size8.Size = new System.Drawing.Size(114, 21);
            this.text_size8.TabIndex = 21;
            this.text_size8.TextChanged += new System.EventHandler(this.text_size8_TextChanged);
            // 
            // text_Name8
            // 
            this.text_Name8.Location = new System.Drawing.Point(138, 255);
            this.text_Name8.Name = "text_Name8";
            this.text_Name8.Size = new System.Drawing.Size(114, 21);
            this.text_Name8.TabIndex = 20;
            this.text_Name8.TextChanged += new System.EventHandler(this.text_Name8_TextChanged);
            // 
            // text_size7
            // 
            this.text_size7.Location = new System.Drawing.Point(258, 228);
            this.text_size7.Name = "text_size7";
            this.text_size7.Size = new System.Drawing.Size(114, 21);
            this.text_size7.TabIndex = 19;
            this.text_size7.TextChanged += new System.EventHandler(this.text_size7_TextChanged);
            // 
            // text_Name7
            // 
            this.text_Name7.Location = new System.Drawing.Point(138, 228);
            this.text_Name7.Name = "text_Name7";
            this.text_Name7.Size = new System.Drawing.Size(114, 21);
            this.text_Name7.TabIndex = 18;
            this.text_Name7.TextChanged += new System.EventHandler(this.text_Name7_TextChanged);
            // 
            // text_size6
            // 
            this.text_size6.Location = new System.Drawing.Point(258, 201);
            this.text_size6.Name = "text_size6";
            this.text_size6.Size = new System.Drawing.Size(114, 21);
            this.text_size6.TabIndex = 17;
            this.text_size6.TextChanged += new System.EventHandler(this.text_size6_TextChanged);
            // 
            // text_Name6
            // 
            this.text_Name6.Location = new System.Drawing.Point(138, 201);
            this.text_Name6.Name = "text_Name6";
            this.text_Name6.Size = new System.Drawing.Size(114, 21);
            this.text_Name6.TabIndex = 16;
            this.text_Name6.TextChanged += new System.EventHandler(this.text_Name6_TextChanged);
            // 
            // text_size5
            // 
            this.text_size5.Location = new System.Drawing.Point(258, 174);
            this.text_size5.Name = "text_size5";
            this.text_size5.Size = new System.Drawing.Size(114, 21);
            this.text_size5.TabIndex = 15;
            this.text_size5.TextChanged += new System.EventHandler(this.text_size5_TextChanged);
            // 
            // text_Name5
            // 
            this.text_Name5.Location = new System.Drawing.Point(138, 174);
            this.text_Name5.Name = "text_Name5";
            this.text_Name5.Size = new System.Drawing.Size(114, 21);
            this.text_Name5.TabIndex = 14;
            this.text_Name5.TextChanged += new System.EventHandler(this.text_Name5_TextChanged);
            // 
            // text_Log
            // 
            this.text_Log.Location = new System.Drawing.Point(138, 358);
            this.text_Log.Name = "text_Log";
            this.text_Log.Size = new System.Drawing.Size(234, 21);
            this.text_Log.TabIndex = 22;
            this.text_Log.TextChanged += new System.EventHandler(this.text_Log_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(136, 343);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 12);
            this.label4.TabIndex = 23;
            this.label4.Text = "Log";
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(138, 308);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(234, 23);
            this.progressBar.TabIndex = 24;
            this.progressBar.Click += new System.EventHandler(this.progressBar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(136, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 25;
            this.label3.Text = "진행률";
            // 
            // radio_File1
            // 
            this.radio_File1.AutoSize = true;
            this.radio_File1.Location = new System.Drawing.Point(389, 65);
            this.radio_File1.Name = "radio_File1";
            this.radio_File1.Size = new System.Drawing.Size(49, 16);
            this.radio_File1.TabIndex = 35;
            this.radio_File1.TabStop = true;
            this.radio_File1.Text = "File1";
            this.radio_File1.UseVisualStyleBackColor = true;
            this.radio_File1.CheckedChanged += new System.EventHandler(this.radio_File1_CheckedChanged);
            // 
            // radio_File2
            // 
            this.radio_File2.AutoSize = true;
            this.radio_File2.Location = new System.Drawing.Point(389, 92);
            this.radio_File2.Name = "radio_File2";
            this.radio_File2.Size = new System.Drawing.Size(49, 16);
            this.radio_File2.TabIndex = 36;
            this.radio_File2.TabStop = true;
            this.radio_File2.Text = "File2";
            this.radio_File2.UseVisualStyleBackColor = true;
            this.radio_File2.CheckedChanged += new System.EventHandler(this.radio_File2_CheckedChanged);
            // 
            // radio_File3
            // 
            this.radio_File3.AutoSize = true;
            this.radio_File3.Location = new System.Drawing.Point(389, 119);
            this.radio_File3.Name = "radio_File3";
            this.radio_File3.Size = new System.Drawing.Size(49, 16);
            this.radio_File3.TabIndex = 37;
            this.radio_File3.TabStop = true;
            this.radio_File3.Text = "File3";
            this.radio_File3.UseVisualStyleBackColor = true;
            this.radio_File3.CheckedChanged += new System.EventHandler(this.radio_File3_CheckedChanged);
            // 
            // radio_File4
            // 
            this.radio_File4.AutoSize = true;
            this.radio_File4.Location = new System.Drawing.Point(389, 146);
            this.radio_File4.Name = "radio_File4";
            this.radio_File4.Size = new System.Drawing.Size(49, 16);
            this.radio_File4.TabIndex = 38;
            this.radio_File4.TabStop = true;
            this.radio_File4.Text = "File4";
            this.radio_File4.UseVisualStyleBackColor = true;
            this.radio_File4.CheckedChanged += new System.EventHandler(this.radio_File4_CheckedChanged);
            // 
            // radio_File5
            // 
            this.radio_File5.AutoSize = true;
            this.radio_File5.Location = new System.Drawing.Point(389, 174);
            this.radio_File5.Name = "radio_File5";
            this.radio_File5.Size = new System.Drawing.Size(49, 16);
            this.radio_File5.TabIndex = 39;
            this.radio_File5.TabStop = true;
            this.radio_File5.Text = "File5";
            this.radio_File5.UseVisualStyleBackColor = true;
            this.radio_File5.CheckedChanged += new System.EventHandler(this.radio_File5_CheckedChanged);
            // 
            // radio_File6
            // 
            this.radio_File6.AutoSize = true;
            this.radio_File6.Location = new System.Drawing.Point(389, 201);
            this.radio_File6.Name = "radio_File6";
            this.radio_File6.Size = new System.Drawing.Size(49, 16);
            this.radio_File6.TabIndex = 40;
            this.radio_File6.TabStop = true;
            this.radio_File6.Text = "File6";
            this.radio_File6.UseVisualStyleBackColor = true;
            this.radio_File6.CheckedChanged += new System.EventHandler(this.radio_File6_CheckedChanged);
            // 
            // radio_File7
            // 
            this.radio_File7.AutoSize = true;
            this.radio_File7.Location = new System.Drawing.Point(389, 228);
            this.radio_File7.Name = "radio_File7";
            this.radio_File7.Size = new System.Drawing.Size(49, 16);
            this.radio_File7.TabIndex = 41;
            this.radio_File7.TabStop = true;
            this.radio_File7.Text = "File7";
            this.radio_File7.UseVisualStyleBackColor = true;
            this.radio_File7.CheckedChanged += new System.EventHandler(this.radio_File7_CheckedChanged);
            // 
            // radio_File8
            // 
            this.radio_File8.AutoSize = true;
            this.radio_File8.Location = new System.Drawing.Point(389, 255);
            this.radio_File8.Name = "radio_File8";
            this.radio_File8.Size = new System.Drawing.Size(49, 16);
            this.radio_File8.TabIndex = 42;
            this.radio_File8.TabStop = true;
            this.radio_File8.Text = "File8";
            this.radio_File8.UseVisualStyleBackColor = true;
            this.radio_File8.CheckedChanged += new System.EventHandler(this.radio_File8_CheckedChanged);
            // 
            // button_Wiping
            // 
            this.button_Wiping.Location = new System.Drawing.Point(34, 123);
            this.button_Wiping.Name = "button_Wiping";
            this.button_Wiping.Size = new System.Drawing.Size(75, 23);
            this.button_Wiping.TabIndex = 3;
            this.button_Wiping.Text = "Safe Shift";
            this.button_Wiping.UseVisualStyleBackColor = true;
            this.button_Wiping.Click += new System.EventHandler(this.button_Wiping_Click);
            // 
            // button_File
            // 
            this.button_File.Location = new System.Drawing.Point(34, 65);
            this.button_File.Name = "button_File";
            this.button_File.Size = new System.Drawing.Size(75, 23);
            this.button_File.TabIndex = 0;
            this.button_File.Text = "FILE";
            this.button_File.UseVisualStyleBackColor = true;
            this.button_File.Click += new System.EventHandler(this.button_File_Click);
            // 
            // frame_Glutton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 444);
            this.Controls.Add(this.radio_File8);
            this.Controls.Add(this.radio_File7);
            this.Controls.Add(this.radio_File6);
            this.Controls.Add(this.radio_File5);
            this.Controls.Add(this.radio_File4);
            this.Controls.Add(this.radio_File3);
            this.Controls.Add(this.radio_File2);
            this.Controls.Add(this.radio_File1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.text_Log);
            this.Controls.Add(this.text_size8);
            this.Controls.Add(this.text_Name8);
            this.Controls.Add(this.text_size7);
            this.Controls.Add(this.text_Name7);
            this.Controls.Add(this.text_size6);
            this.Controls.Add(this.text_Name6);
            this.Controls.Add(this.text_size5);
            this.Controls.Add(this.text_Name5);
            this.Controls.Add(this.text_size4);
            this.Controls.Add(this.text_Name4);
            this.Controls.Add(this.text_size3);
            this.Controls.Add(this.text_Name3);
            this.Controls.Add(this.text_size2);
            this.Controls.Add(this.text_Name2);
            this.Controls.Add(this.text_size1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.text_Name1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_Wiping);
            this.Controls.Add(this.button_Decryption);
            this.Controls.Add(this.button_File);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frame_Glutton";
            this.Text = "Glutton";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_Decryption;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_Name1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox text_size1;
        private System.Windows.Forms.TextBox text_Name2;
        private System.Windows.Forms.TextBox text_size2;
        private System.Windows.Forms.TextBox text_Name3;
        private System.Windows.Forms.TextBox text_size3;
        private System.Windows.Forms.TextBox text_Name4;
        private System.Windows.Forms.TextBox text_size4;
        private System.Windows.Forms.TextBox text_Name5;
        private System.Windows.Forms.TextBox text_size5;
        private System.Windows.Forms.TextBox text_Name6;
        private System.Windows.Forms.TextBox text_size6;
        private System.Windows.Forms.TextBox text_Name7;
        private System.Windows.Forms.TextBox text_size7;
        private System.Windows.Forms.TextBox text_Name8;
        private System.Windows.Forms.TextBox text_size8;
        private System.Windows.Forms.TextBox text_Log;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radio_File1;
        private System.Windows.Forms.RadioButton radio_File2;
        private System.Windows.Forms.RadioButton radio_File3;
        private System.Windows.Forms.RadioButton radio_File4;
        private System.Windows.Forms.RadioButton radio_File5;
        private System.Windows.Forms.RadioButton radio_File6;
        private System.Windows.Forms.RadioButton radio_File7;
        private System.Windows.Forms.RadioButton radio_File8;
        private System.Windows.Forms.Button button_Wiping;
        private System.Windows.Forms.Button button_File;
    }
}

