﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gluttonGUI
{
    public partial class frame_Glutton : Form
    {
        public frame_Glutton()
        {
            InitializeComponent();
        }

        private void button_File_Click(object sender, EventArgs e)
        {
            OpenFileDialog pFileDlg = new OpenFileDialog();
            pFileDlg.Filter = "Text Files(*.txt)|*.txt|All Files(*.*)|*.*";
            pFileDlg.Title = "주소 파일을 선택해 주세요.";
            if (pFileDlg.ShowDialog() == DialogResult.OK)
            {
                String strFullPathFile = pFileDlg.FileName; // 파일 경로
            }
        }

        private void button_Decryption_Click(object sender, EventArgs e)
        {
            frame_Password pg = new frame_Password();
            pg.ShowDialog();
        }

        private void button_Wiping_Click(object sender, EventArgs e)
        {
            OpenFileDialog pFileDlg = new OpenFileDialog();
            pFileDlg.Filter = "Text Files(*.txt)|*.txt|All Files(*.*)|*.*";
            pFileDlg.Title = "주소 파일을 선택해 주세요.";
            if (pFileDlg.ShowDialog() == DialogResult.OK)
            {
                String strFullPathFile = pFileDlg.FileName; // 파일 경로
            }
        }

        private void text_Name1_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Name2_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Name3_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Name4_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Name5_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Name6_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Name7_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Name8_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_size1_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_size2_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_size3_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_size4_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_size5_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_size6_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_size7_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_size8_TextChanged(object sender, EventArgs e)
        {

        }

        private void radio_File1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radio_File2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radio_File3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radio_File4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radio_File5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radio_File6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radio_File7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radio_File8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void progressBar_Click(object sender, EventArgs e)
        {

        }

        private void text_Log_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
