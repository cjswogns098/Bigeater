﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace passwordGlutton
{
    public partial class frame_Password : Form
    {
        public frame_Password()
        {
            InitializeComponent();
        }

        private void text_Password_TextChanged(object sender, EventArgs e)
        {
            // Set to no text.
            text_Password.Text = "";
            // The password character is an asterisk.
            text_Password.PasswordChar = '*';
            // The control will allow no more than 14 characters.
            text_Password.MaxLength = 14;
        }
    }
}
